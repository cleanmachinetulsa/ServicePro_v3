
import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Lock, Fingerprint } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isBiometricAvailable, setIsBiometricAvailable] = useState(false);
  const [isBiometricLoading, setIsBiometricLoading] = useState(false);

  useEffect(() => {
    // Check if WebAuthn is supported
    if (window.PublicKeyCredential) {
      setIsBiometricAvailable(true);
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
        credentials: 'include', // CRITICAL: Allow cookies to be sent/received
      });

      const data = await response.json();

      if (data.success) {
        // Session is now stored in HttpOnly cookie automatically
        toast({ title: 'Login successful', description: 'Welcome back!' });
        
        // Small delay to ensure session cookie is set, then force page reload to /messages
        setTimeout(() => {
          window.location.href = '/messages';
        }, 100);
      } else {
        toast({ 
          title: 'Login failed', 
          description: data.message || 'Invalid credentials',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({ 
        title: 'Error', 
        description: 'Failed to login',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Base64URL decode helper (WebAuthn uses Base64URL, not standard Base64)
  const base64UrlDecode = (base64url: string): Uint8Array => {
    // Replace URL-safe characters
    let base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
    
    // Add padding if necessary
    const padding = base64.length % 4;
    if (padding === 2) {
      base64 += '==';
    } else if (padding === 3) {
      base64 += '=';
    }
    
    const rawData = atob(base64);
    return Uint8Array.from(rawData, c => c.charCodeAt(0));
  };

  // Base64URL encode helper
  const base64UrlEncode = (buffer: ArrayBuffer): string => {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  };

  const handleBiometricLogin = async () => {
    setIsBiometricLoading(true);

    try {
      // Get authentication options from server (requires username)
      const optionsResponse = await fetch('/api/webauthn/authenticate/options', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username: 'admin' }), // Default to admin user
      });

      if (!optionsResponse.ok) {
        throw new Error('Failed to get authentication options');
      }

      const options = await optionsResponse.json();

      // Check if we have credentials to authenticate with
      if (!options.allowCredentials || options.allowCredentials.length === 0) {
        throw new Error('No biometric credentials registered. Please use password login.');
      }

      // Use WebAuthn to authenticate with Base64URL decoding
      const credential = await navigator.credentials.get({
        publicKey: {
          challenge: base64UrlDecode(options.challenge),
          allowCredentials: options.allowCredentials.map((cred: any) => ({
            ...cred,
            id: base64UrlDecode(cred.id),
          })),
          timeout: 60000,
        },
      }) as PublicKeyCredential;

      if (!credential) {
        throw new Error('Authentication cancelled');
      }

      // Send credential to server for verification with Base64URL encoding
      const response = credential.response as AuthenticatorAssertionResponse;
      const verifyResponse = await fetch('/api/webauthn/authenticate/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          id: base64UrlEncode(credential.rawId),
          response: {
            authenticatorData: base64UrlEncode(response.authenticatorData),
            clientDataJSON: base64UrlEncode(response.clientDataJSON),
            signature: base64UrlEncode(response.signature),
            userHandle: response.userHandle ? base64UrlEncode(response.userHandle) : null,
          },
        }),
      });

      const data = await verifyResponse.json();

      if (data.success) {
        toast({ 
          title: 'Biometric login successful', 
          description: 'Welcome back!' 
        });
        
        setTimeout(() => {
          window.location.href = '/messages';
        }, 100);
      } else {
        toast({ 
          title: 'Biometric login failed', 
          description: data.message || 'Authentication failed',
          variant: 'destructive'
        });
      }
    } catch (error: any) {
      console.error('Biometric login error:', error);
      toast({ 
        title: 'Biometric login failed', 
        description: error.message || 'Please try again or use password',
        variant: 'destructive'
      });
    } finally {
      setIsBiometricLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-blue-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Lock className="h-12 w-12 text-blue-600" />
          </div>
          <CardTitle className="text-2xl">Admin Login</CardTitle>
          <CardDescription>
            Sign in to access the admin dashboard
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={isLoading} data-testid="button-login">
              {isLoading ? 'Signing in...' : 'Sign In'}
            </Button>

            {/* BIOMETRIC LOGIN TEMPORARILY DISABLED: Backend has 18 TypeScript errors */}
            {/* {isBiometricAvailable && (
              <>
                <div className="relative my-6">
                  <Separator className="my-4" />
                  <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2">
                    <span className="text-xs text-gray-500">OR</span>
                  </div>
                </div>

                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={handleBiometricLogin}
                  disabled={isBiometricLoading}
                  data-testid="button-biometric-login"
                >
                  <Fingerprint className="mr-2 h-4 w-4" />
                  {isBiometricLoading ? 'Authenticating...' : 'Sign in with Biometrics'}
                </Button>
              </>
            )} */}

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                className="text-sm text-blue-600"
                onClick={() => setLocation('/forgot-password')}
                data-testid="link-forgot-password"
              >
                Forgot your password?
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
