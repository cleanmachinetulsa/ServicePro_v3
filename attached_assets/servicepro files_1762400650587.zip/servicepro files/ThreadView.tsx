import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { 
  Bot, 
  User, 
  Phone, 
  Send, 
  Loader2, 
  ArrowLeftRight,
  Clock,
  Sparkles,
  MessageSquare,
  ChevronDown,
  ChevronRight,
  Code2
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import io from 'socket.io-client';
import type { Conversation, Message, QuickReplyCategory, QuickReplyTemplate } from '@shared/schema';
import BookingPanel from './BookingPanel';

interface ReplySuggestion {
  id: string;
  content: string;
  type: 'informational' | 'scheduling' | 'service_related' | 'closing' | 'general';
  confidence: number;
}

interface CategoryWithTemplates extends QuickReplyCategory {
  templates: QuickReplyTemplate[];
}

interface ThreadViewProps {
  conversationId: number;
}

export default function ThreadView({ conversationId }: ThreadViewProps) {
  const [messageInput, setMessageInput] = useState('');
  const [expandedCategories, setExpandedCategories] = useState<Set<number>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  // Fetch current user
  const { data: currentUserData } = useQuery<{ success: boolean; user: { username: string } }>({
    queryKey: ['/api/users/me'],
  });
  const currentUser = currentUserData?.user;

  // Fetch conversation details with messages
  const { data: conversationData, isLoading: conversationLoading} = useQuery<{ success: boolean; data: Conversation & { messages: Message[] } }>({
    queryKey: [`/api/conversations/${conversationId}`],
    refetchInterval: 5000,
  });

  const conversation = conversationData?.data;

  // Mark conversation as read when viewing
  useEffect(() => {
    if (conversation && (conversation.unreadCount || 0) > 0) {
      apiRequest('POST', `/api/conversations/${conversationId}/mark-read`).catch(console.error);
    }
  }, [conversationId, conversation?.unreadCount]);

  // Fetch AI suggestions
  const { data: suggestionsData, refetch: refetchSuggestions } = useQuery<{ success: boolean; suggestions: ReplySuggestion[] }>({
    queryKey: [`/api/conversations/${conversationId}/suggestions`],
    enabled: !!conversation && conversation.controlMode === 'manual',
  });

  const suggestions = suggestionsData?.suggestions || [];

  // Fetch quick reply templates
  const { data: quickRepliesData } = useQuery<{ success: boolean; categories: CategoryWithTemplates[] }>({
    queryKey: ['/api/quick-replies/categories'],
  });

  const quickReplyCategories = quickRepliesData?.categories || [];

  // Fetch template variables
  const { data: templateVariablesData } = useQuery<{ success: boolean; variables: Array<{ variable: string; description: string; example: string }> }>({
    queryKey: ['/api/template-variables'],
  });

  const templateVariables = templateVariablesData?.variables || [];

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest('POST', `/api/conversations/${conversationId}/send-message`, { 
        content,
        channel: conversation?.platform || 'web'
      });
      return response.json();
    },
    onSuccess: () => {
      setMessageInput('');
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
      refetchSuggestions();
    },
  });

  // Return to AI mutation
  const returnToAIMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/conversations/${conversationId}/return-to-ai`, { 
        agentName: currentUser?.username || 'Agent',
        notifyCustomer: true
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
  });

  // Thread management mutations
  const assignToMeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/conversations/${conversationId}/assign`, {
        agentName: currentUser?.username || 'Agent',
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
  });

  const snoozeMutation = useMutation({
    mutationFn: async (snoozedUntil: string | null) => {
      const response = await apiRequest('POST', `/api/conversations/${conversationId}/snooze`, {
        snoozedUntil,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
  });

  const resolveMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/conversations/${conversationId}/resolve`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
  });

  // WebSocket for real-time updates
  useEffect(() => {
    const socket = io();

    socket.on('connect', () => {
      console.log('[THREAD VIEW] Connected to WebSocket');
      socket.emit('join_conversation', conversationId);
    });

    socket.on('new_message', (data: any) => {
      if (data.conversationId === conversationId) {
        console.log('[THREAD VIEW] New message received:', data);
        queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
        refetchSuggestions();
      }
    });

    socket.on('conversation_updated', (data: any) => {
      if (data.conversationId === conversationId) {
        console.log('[THREAD VIEW] Conversation updated:', data);
        queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
      }
    });

    socket.on('control_mode_changed', (data: any) => {
      if (data.conversationId === conversationId) {
        console.log('[THREAD VIEW] Control mode changed:', data);
        queryClient.invalidateQueries({ queryKey: [`/api/conversations/${conversationId}`] });
      }
    });

    return () => {
      socket.emit('leave_conversation', conversationId);
      socket.disconnect();
    };
  }, [conversationId, queryClient]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversation?.messages]);

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      const messageToSend = messageInput;
      setMessageInput(''); // Clear immediately (optimistic)
      sendMessageMutation.mutate(messageToSend);
    }
  };

  const handleSuggestionClick = (suggestionContent: string) => {
    setMessageInput(suggestionContent);
  };

  const insertTemplateVariable = (variable: string) => {
    setMessageInput(prev => prev + variable + ' ');
  };

  const handleQuickReplyClick = async (templateId: number, content: string) => {
    // Update last used timestamp
    await apiRequest('POST', `/api/quick-replies/templates/${templateId}/use`);
    
    // Send immediately
    sendMessageMutation.mutate(content);
  };

  const toggleCategory = (categoryId: number) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(categoryId)) {
      newExpanded.delete(categoryId);
    } else {
      newExpanded.add(categoryId);
    }
    setExpandedCategories(newExpanded);
  };

  const getStatusBadge = () => {
    if (!conversation) return null;

    switch (conversation.controlMode) {
      case 'manual':
        return (
          <Badge variant="default" className="gap-1 bg-purple-600" data-testid="badge-status-manual">
            <User className="h-3 w-3" />
            Manual Mode
          </Badge>
        );
      case 'auto':
        return (
          <Badge variant="secondary" className="gap-1" data-testid="badge-status-ai">
            <Bot className="h-3 w-3" />
            AI Mode
          </Badge>
        );
      case 'paused':
        return (
          <Badge variant="outline" className="gap-1" data-testid="badge-status-paused">
            <Clock className="h-3 w-3" />
            Paused
          </Badge>
        );
      default:
        return null;
    }
  };

  const getMessageBackground = (sender: string) => {
    switch (sender) {
      case 'customer':
        return 'bg-gray-100 dark:bg-gray-800';
      case 'ai':
        return 'bg-blue-100 dark:bg-blue-900';
      case 'agent':
        return 'bg-purple-100 dark:bg-purple-900';
      default:
        return 'bg-gray-100 dark:bg-gray-800';
    }
  };

  const getSenderIcon = (sender: string) => {
    switch (sender) {
      case 'customer':
        return <User className="h-4 w-4" />;
      case 'ai':
        return <Bot className="h-4 w-4" />;
      case 'agent':
        return <User className="h-4 w-4 text-purple-600" />;
      default:
        return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getSenderLabel = (sender: string) => {
    switch (sender) {
      case 'customer':
        return conversation?.customerName || conversation?.customerPhone || 'Customer';
      case 'ai':
        return 'Clean Machine Assistant';
      case 'agent':
        return conversation?.assignedAgent || 'Agent';
      default:
        return sender;
    }
  };

  if (conversationLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Conversation not found</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-950">
      {/* Conversation Controls Toolbar */}
      <div className="border-b dark:border-gray-800 bg-white dark:bg-gray-900 px-6 py-4 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <Phone className="h-5 w-5 text-primary" />
              <div>
                <h2 className="font-semibold" data-testid="text-customer-name">
                  {conversation.customerName || conversation.customerPhone}
                </h2>
                {conversation.customerName && (
                  <p className="text-sm text-muted-foreground" data-testid="text-customer-phone">
                    {conversation.customerPhone}
                  </p>
                )}
              </div>
            </div>
            {getStatusBadge()}
          </div>

          <div className="flex items-center gap-2">
            {/* Assign to Me */}
            {!conversation.assignedAgent && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => assignToMeMutation.mutate()}
                disabled={assignToMeMutation.isPending}
                className="gap-2"
                data-testid="button-assign-to-me"
              >
                {assignToMeMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <User className="h-4 w-4" />
                )}
                Assign to Me
              </Button>
            )}

            {/* Snooze */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  data-testid="button-snooze"
                >
                  <Clock className="h-4 w-4" />
                  Snooze
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-48 p-2">
                <div className="space-y-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => {
                      const snoozeUntil = new Date(Date.now() + 1 * 60 * 60 * 1000).toISOString();
                      snoozeMutation.mutate(snoozeUntil);
                    }}
                  >
                    1 hour
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => {
                      const snoozeUntil = new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString();
                      snoozeMutation.mutate(snoozeUntil);
                    }}
                  >
                    4 hours
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => {
                      const tomorrow = new Date();
                      tomorrow.setDate(tomorrow.getDate() + 1);
                      tomorrow.setHours(9, 0, 0, 0);
                      snoozeMutation.mutate(tomorrow.toISOString());
                    }}
                  >
                    Tomorrow 9 AM
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => {
                      const nextWeek = new Date();
                      nextWeek.setDate(nextWeek.getDate() + 7);
                      nextWeek.setHours(9, 0, 0, 0);
                      snoozeMutation.mutate(nextWeek.toISOString());
                    }}
                  >
                    Next week
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            {/* Mark as Resolved */}
            {conversation.status !== 'closed' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => resolveMutation.mutate()}
                disabled={resolveMutation.isPending}
                className="gap-2"
                data-testid="button-resolve"
              >
                {resolveMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <MessageSquare className="h-4 w-4" />
                )}
                Mark Resolved
              </Button>
            )}

            {conversation.controlMode === 'manual' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => returnToAIMutation.mutate()}
                disabled={returnToAIMutation.isPending}
                className="gap-2"
                data-testid="button-hand-to-ai"
              >
                {returnToAIMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ArrowLeftRight className="h-4 w-4" />
                )}
                Hand to AI
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Main Message Area */}
        <div className="flex-1 flex flex-col min-h-0">
          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4 max-w-4xl mx-auto">
              {conversation.messages && conversation.messages.length > 0 ? (
                <>
                  {conversation.messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === 'customer' ? 'justify-start' : 'justify-end'}`}
                      data-testid={`message-${message.id}`}
                    >
                      <div
                        className={`max-w-[80%] sm:max-w-[70%] rounded-lg p-3 ${getMessageBackground(message.sender)}`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          {getSenderIcon(message.sender)}
                          <span className="font-semibold text-sm" data-testid={`sender-${message.id}`}>
                            {getSenderLabel(message.sender)}
                          </span>
                          <span className="text-xs text-muted-foreground" data-testid={`timestamp-${message.id}`}>
                            {message.timestamp ? formatDistanceToNow(new Date(message.timestamp), { addSuffix: true }) : 'Just now'}
                          </span>
                        </div>
                        <p className="text-sm whitespace-pre-wrap" data-testid={`content-${message.id}`}>
                          {message.content}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  No messages yet
                </div>
              )}
            </div>
          </ScrollArea>

          {/* AI Suggestions - Enhanced UI */}
          {conversation.controlMode === 'manual' && suggestions.length > 0 && (
            <div className="border-t dark:border-gray-800 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20 px-4 py-3">
              <div className="flex items-center gap-2 mb-3">
                <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-1.5 rounded-lg">
                  <Sparkles className="h-3.5 w-3.5 text-white" />
                </div>
                <span className="text-sm font-semibold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  AI-Powered Suggestions
                </span>
                <Badge variant="secondary" className="text-xs">
                  {suggestions.length} available
                </Badge>
              </div>
              <div className="flex flex-wrap gap-2 max-w-4xl mx-auto">
                {suggestions.map((suggestion, index) => (
                  <Button
                    key={suggestion.id}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSuggestionClick(suggestion.content)}
                    className="text-xs h-auto py-2.5 px-4 whitespace-normal text-left bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 border-blue-200 dark:border-blue-800 transition-all hover:scale-105 hover:shadow-md"
                    data-testid={`suggestion-${suggestion.id}`}
                  >
                    <div className="flex items-start gap-2">
                      <span className="font-mono text-blue-600 dark:text-blue-400 text-[10px] mt-0.5">
                        {index + 1}
                      </span>
                      <span className="flex-1">{suggestion.content}</span>
                      {suggestion.confidence >= 0.9 && (
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                          High
                        </Badge>
                      )}
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Integrated Booking Panel */}
          <BookingPanel conversationId={conversationId} />

          {/* Message Input - Enhanced */}
          {conversation.controlMode === 'manual' && (
            <div className="border-t dark:border-gray-800 bg-white dark:bg-gray-900 px-4 py-4 shadow-lg">
              <div className="flex gap-3 max-w-4xl mx-auto items-end">
                <div className="flex-1 relative">
                  <Textarea
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    placeholder="Type your message here... (Press Enter to send, Shift+Enter for new line)"
                    className="min-h-[100px] resize-none text-base leading-relaxed bg-gray-50 dark:bg-gray-800 border-gray-300 dark:border-gray-700 focus:ring-2 focus:ring-primary/30 rounded-xl pr-24"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    disabled={sendMessageMutation.isPending}
                    data-testid="input-message"
                  />
                  <div className="absolute bottom-3 right-3 text-xs text-muted-foreground">
                    {messageInput.length > 0 && (
                      <span className="mr-2">{messageInput.length} chars</span>
                    )}
                    <kbd className="px-1.5 py-0.5 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg dark:bg-gray-600 dark:text-gray-100 dark:border-gray-500">
                      Enter
                    </kbd>
                    <span className="mx-1">to send</span>
                  </div>
                </div>
                
                {/* Template Variables Button */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="h-[100px] w-14 rounded-xl border-2 border-gray-300 dark:border-gray-700 hover:border-primary dark:hover:border-primary transition-all"
                      data-testid="button-template-variables"
                      title="Insert template variable"
                    >
                      <div className="flex flex-col items-center gap-1">
                        <Code2 className="h-5 w-5 text-primary" />
                        <span className="text-[10px] font-medium">Vars</span>
                      </div>
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-80 p-0" align="end">
                    <div className="p-3 border-b dark:border-gray-800">
                      <h3 className="font-semibold text-sm flex items-center gap-2">
                        <Code2 className="h-4 w-4 text-primary" />
                        Template Variables
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        Click to insert dynamic content
                      </p>
                    </div>
                    <ScrollArea className="max-h-[300px]">
                      <div className="p-2">
                        {templateVariables.map((template) => (
                          <button
                            key={template.variable}
                            onClick={() => insertTemplateVariable(template.variable)}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                            data-testid={`template-var-${template.variable}`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="font-mono text-xs font-semibold text-primary truncate">
                                  {template.variable}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {template.description}
                                </div>
                              </div>
                              <Badge variant="secondary" className="text-[10px] shrink-0">
                                {template.example}
                              </Badge>
                            </div>
                          </button>
                        ))}
                      </div>
                    </ScrollArea>
                  </PopoverContent>
                </Popover>

                <Button
                  onClick={handleSendMessage}
                  disabled={!messageInput.trim() || sendMessageMutation.isPending}
                  className="h-[100px] w-20 bg-primary hover:bg-primary/90 text-white rounded-xl shadow-lg hover:shadow-xl transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
                  data-testid="button-send"
                >
                  {sendMessageMutation.isPending ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <Send className="h-6 w-6" />
                      <span className="text-xs font-medium">Send</span>
                    </div>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Quick Reply Templates Sidebar - Enhanced */}
        {conversation.controlMode === 'manual' && quickReplyCategories.length > 0 && (
          <div className="lg:w-80 border-t lg:border-t-0 lg:border-l dark:border-gray-800 bg-gray-50 dark:bg-gray-900 overflow-y-auto max-h-[400px] lg:max-h-full">
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <div className="bg-primary/10 p-1.5 rounded-lg">
                    <MessageSquare className="h-4 w-4 text-primary" />
                  </div>
                  Quick Replies
                </h3>
                <Badge variant="outline" className="text-xs">
                  {quickReplyCategories.reduce((sum, cat) => sum + cat.templates.length, 0)} templates
                </Badge>
              </div>
              
              <div className="space-y-2">
                {quickReplyCategories.map((category) => (
                  <Collapsible
                    key={category.id}
                    open={expandedCategories.has(category.id)}
                    onOpenChange={() => toggleCategory(category.id)}
                  >
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="w-full justify-between"
                        data-testid={`category-${category.id}`}
                      >
                        <span className="flex items-center gap-2">
                          {category.icon && <span>{category.icon}</span>}
                          {category.name}
                        </span>
                        {expandedCategories.has(category.id) ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-1 mt-1">
                      {category.templates.map((template) => (
                        <Button
                          key={template.id}
                          variant="outline"
                          size="sm"
                          onClick={() => handleQuickReplyClick(template.id, template.content)}
                          className="w-full text-left justify-start text-xs h-auto py-2 px-3 whitespace-normal"
                          disabled={sendMessageMutation.isPending}
                          data-testid={`template-${template.id}`}
                        >
                          {template.content}
                        </Button>
                      ))}
                    </CollapsibleContent>
                  </Collapsible>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
