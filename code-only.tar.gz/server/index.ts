import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import cors from "cors";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import pg from "pg";
import { demoProtectionMiddleware } from "./demoProtection";
import loyaltyRouter from "./loyaltyApi";
import techProfilesRouter from "./routes.techProfiles";
import aiBioCoachRouter from "./routes.aiBioCoach";
import adminEmployeesRouter from "./routes.adminEmployees";
import payerApprovalRouter from "./routes.payerApproval";
import { registerContactsRoutes } from "./routes.contacts";
import stripeWebhooksRouter from "./routes.stripeWebhooks";
import pushNotificationsRouter from "./routes.pushNotifications";
import path from "path";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Serve uploaded files from public directory
app.use('/uploads', express.static(path.join(process.cwd(), 'public', 'uploads')));
// Serve technician profile photos
app.use('/tech_profiles', express.static(path.join(process.cwd(), 'public', 'tech_profiles')));
// Serve service worker for PWA (must be served from root)
app.get('/service-worker.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript');
  res.setHeader('Service-Worker-Allowed', '/');
  res.sendFile(path.join(process.cwd(), 'public', 'service-worker.js'));
});

// Add CORS middleware - must come before session middleware
app.use(cors({
  origin: true, // Allow requests from same origin
  credentials: true, // Allow cookies
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

// Validate SESSION_SECRET in production
if (process.env.NODE_ENV === 'production' && !process.env.SESSION_SECRET) {
  console.error('CRITICAL: SESSION_SECRET environment variable is required in production!');
  process.exit(1);
}

// Require strong SESSION_SECRET (at least 32 characters)
const sessionSecret = process.env.SESSION_SECRET || 'clean-machine-session-secret-change-in-production';
if (process.env.NODE_ENV === 'production' && sessionSecret.length < 32) {
  console.error('CRITICAL: SESSION_SECRET must be at least 32 characters long!');
  process.exit(1);
}

// Configure PostgreSQL session store for persistent sessions
const PgSession = connectPgSimple(session);
const pgPool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
});

// Configure express-session with PostgreSQL store and secure HttpOnly cookies
app.use(session({
  store: new PgSession({
    pool: pgPool,
    tableName: 'session', // Table name for storing sessions
    createTableIfMissing: true, // Auto-create the session table
    pruneSessionInterval: 60 * 60, // Prune expired sessions every hour
  }),
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true, // Prevents JavaScript access (XSS protection)
    secure: true, // Always true for Replit (HTTPS in dev & prod)
    sameSite: 'none', // Required for PWA/cross-origin requests
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    path: '/', // Ensure cookie is available on all paths
  },
  name: 'sessionId', // Custom cookie name
  proxy: true, // Trust proxy (Replit uses proxy)
}));

// Apply demo protection middleware
app.use(demoProtectionMiddleware);

// Register loyalty API routes
app.use('/api/invoice', loyaltyRouter);
// Register technician profiles routes
app.use(techProfilesRouter);
// Register AI Bio Coach routes
app.use(aiBioCoachRouter);
// Register admin employees routes
app.use(adminEmployeesRouter);
// Register push notification routes
app.use('/api/push', pushNotificationsRouter);
// Register payer approval routes (public, no auth)
app.use(payerApprovalRouter);
// Register Stripe webhook routes (public, verified via signature)
app.use(stripeWebhooksRouter);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Initialize push notifications table
  const { initializePushNotificationsTable } = await import('./initPushNotifications');
  await initializePushNotificationsTable();
  
  const server = await registerRoutes(app);
  
  // Register contacts routes
  registerContactsRoutes(app);

  // Start timeout monitoring for manual mode conversations
  const { startTimeoutMonitoring } = await import('./timeoutMonitorService');
  startTimeoutMonitoring();
  console.log('[SERVER] Timeout monitoring started');
  
  // Start damage assessment auto-approval monitoring
  const { startDamageAssessmentMonitoring } = await import('./damageAssessmentMonitor');
  startDamageAssessmentMonitoring();
  console.log('[SERVER] Damage assessment monitoring started');
  
  // Start recurring services scheduler and deposit reminders
  const { initializeRecurringServicesScheduler, initializeRecurringServiceReminders, initializeDepositReminders } = await import('./recurringServicesScheduler');
  initializeRecurringServicesScheduler();
  initializeRecurringServiceReminders();
  initializeDepositReminders();
  console.log('[SERVER] Recurring services scheduler, reminders, and deposit reminders started');

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();