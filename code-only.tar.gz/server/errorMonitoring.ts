import { sendSMS } from './notifications';
import { db } from './db';
import { errorLogs } from '@shared/schema';

// In-memory tracking for duplicate error prevention
const recentErrors = new Map<string, number>();
const ERROR_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutes

interface ErrorDetails {
  type: 'api' | 'database' | 'external_service' | 'validation' | 'runtime' | 'unknown';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  stack?: string;
  endpoint?: string;
  userId?: string;
  requestData?: any;
  metadata?: any;
}

/**
 * Log error to database and optionally notify admin
 */
export async function logError(details: ErrorDetails): Promise<void> {
  try {
    // Create error signature to prevent duplicate notifications
    const errorSignature = `${details.type}:${details.endpoint}:${details.message.substring(0, 100)}`;
    const now = Date.now();
    const lastOccurrence = recentErrors.get(errorSignature);

    // Skip if same error occurred recently (within cooldown period)
    if (lastOccurrence && (now - lastOccurrence) < ERROR_COOLDOWN_MS) {
      console.log(`[ERROR MONITOR] Duplicate error within cooldown: ${errorSignature}`);
      return;
    }

    // Update recent errors map
    recentErrors.set(errorSignature, now);

    // Log to database
    await db.insert(errorLogs).values({
      errorType: details.type,
      severity: details.severity,
      message: details.message,
      stack: details.stack || null,
      endpoint: details.endpoint || null,
      userId: details.userId || null,
      requestData: details.requestData || null,
      metadata: details.metadata || null,
    });

    console.error(`[ERROR MONITOR] ${details.severity.toUpperCase()} - ${details.type}: ${details.message}`);

    // Notify admin for high/critical errors
    if (details.severity === 'high' || details.severity === 'critical') {
      await notifyAdmin(details);
    }

    // Clean up old entries from memory map (keep last hour)
    const oneHourAgo = now - (60 * 60 * 1000);
    for (const [key, timestamp] of recentErrors.entries()) {
      if (timestamp < oneHourAgo) {
        recentErrors.delete(key);
      }
    }
  } catch (error) {
    // Fallback: if error monitoring fails, log to console
    console.error('[ERROR MONITOR] Failed to log error:', error);
    console.error('[ERROR MONITOR] Original error:', details);
  }
}

/**
 * Send notifications to admin about critical errors
 */
async function notifyAdmin(details: ErrorDetails): Promise<void> {
  const message = `CRITICAL ERROR: ${details.type} - ${details.message.substring(0, 100)}`;

  // For high/critical errors during rollout, send SMS
  if (process.env.ROLLOUT_MODE === 'true') {
    try {
      const adminPhone = process.env.ADMIN_PHONE || '9188565304';
      await sendSMS(
        adminPhone,
        message
      );
    } catch (error) {
      console.error('[ERROR MONITOR] Failed to send SMS alert:', error);
    }
  }
}

/**
 * Express middleware for automatic error logging
 */
export function errorMonitoringMiddleware(err: any, req: any, res: any, next: any) {
  // Determine error severity based on status code
  let severity: 'low' | 'medium' | 'high' | 'critical' = 'medium';
  if (err.status >= 500) severity = 'high';
  if (err.status === 500 || !err.status) severity = 'critical';
  if (err.status >= 400 && err.status < 500) severity = 'medium';

  // Determine error type
  let errorType: ErrorDetails['type'] = 'runtime';
  if (err.name === 'ValidationError') errorType = 'validation';
  if (err.message?.includes('database') || err.code?.startsWith('PG')) errorType = 'database';
  if (req.path?.startsWith('/api/')) errorType = 'api';

  // Log the error
  logError({
    type: errorType,
    severity,
    message: err.message || 'Unknown error',
    stack: err.stack,
    endpoint: `${req.method} ${req.path}`,
    userId: req.session?.userId?.toString(),
    requestData: {
      body: req.body,
      query: req.query,
      params: req.params,
    },
    metadata: {
      headers: req.headers,
      ip: req.ip,
      userAgent: req.get('user-agent'),
    },
  });

  // Pass to next error handler
  next(err);
}

/**
 * Wrap async route handlers to catch errors
 */
export function asyncHandler(fn: Function) {
  return (req: any, res: any, next: any) => {
    Promise.resolve(fn(req, res, next)).catch((error) => {
      logError({
        type: 'api',
        severity: 'high',
        message: error.message || 'Async handler error',
        stack: error.stack,
        endpoint: `${req.method} ${req.path}`,
        userId: req.session?.userId?.toString(),
        requestData: {
          body: req.body,
          query: req.query,
        },
      });
      next(error);
    });
  };
}

/**
 * Get recent errors for admin dashboard
 */
export async function getRecentErrors(limit: number = 50): Promise<typeof errorLogs.$inferSelect[]> {
  const { desc } = await import('drizzle-orm');
  return db
    .select()
    .from(errorLogs)
    .orderBy(desc(errorLogs.createdAt))
    .limit(limit);
}

/**
 * Mark error as resolved
 */
export async function markErrorResolved(errorId: number): Promise<void> {
  const { eq } = await import('drizzle-orm');
  await db
    .update(errorLogs)
    .set({ resolved: new Date() })
    .where(eq(errorLogs.id, errorId));
}
