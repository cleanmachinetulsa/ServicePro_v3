import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { 
  Clock, 
  Calendar,
  Settings,
  Save,
  Link as LinkIcon,
  Image as ImageIcon
} from "lucide-react";
import logoBlue from '@assets/generated_images/Clean_Machine_logo_blue_0f30335d.png';
import logoBadge from '@assets/generated_images/Clean_Machine_badge_circular_ff904963.png';
import logoShield from '@assets/generated_images/Clean_Machine_shield_hexagonal_89fc94d0.png';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";

interface BusinessHours {
  startHour: number;
  startMinute: number;
  endHour: number;
  endMinute: number;
  lunchHour: number;
  lunchMinute: number;
  daysOfWeek: number[];
}

export default function BusinessSettings() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Business hours state
  const [businessHours, setBusinessHours] = useState<BusinessHours>({
    startHour: 9,
    startMinute: 0,
    endHour: 15,
    endMinute: 0,
    lunchHour: 12,
    lunchMinute: 0,
    daysOfWeek: [1, 2, 3, 4, 5], // Monday to Friday (0 = Sunday, 6 = Saturday)
  });
  
  const [allowWeekendBookings, setAllowWeekendBookings] = useState<boolean>(false);
  const [halfHourIncrements, setHalfHourIncrements] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [minimumNoticeHours, setMinimumNoticeHours] = useState<number>(24);
  const [maxDriveTimeMinutes, setMaxDriveTimeMinutes] = useState<number>(26);
  const [enableLunchBreak, setEnableLunchBreak] = useState<boolean>(true);
  const [etaPadding, setEtaPadding] = useState<number>(15);
  const [googlePlaceId, setGooglePlaceId] = useState<string>('');
  
  // Available hours and minutes for select dropdowns
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const minutes = [0, 15, 30, 45];
  
  const daysOfWeek = [
    { value: 0, label: "Sunday" },
    { value: 1, label: "Monday" },
    { value: 2, label: "Tuesday" },
    { value: 3, label: "Wednesday" },
    { value: 4, label: "Thursday" },
    { value: 5, label: "Friday" },
    { value: 6, label: "Saturday" },
  ];
  
  const handleSaveBusinessHours = async () => {
    setIsSaving(true);
    try {
      const response = await fetch('/api/business-settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          startHour: businessHours.startHour,
          startMinute: businessHours.startMinute,
          endHour: businessHours.endHour,
          endMinute: businessHours.endMinute,
          lunchHour: businessHours.lunchHour,
          lunchMinute: businessHours.lunchMinute,
          daysOfWeek: businessHours.daysOfWeek,
          enableLunchBreak,
          allowWeekendBookings,
          halfHourIncrements,
          minimumNoticeHours,
          maxDriveTimeMinutes,
          etaPadding,
          googlePlaceId,
        }),
      });
      
      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to save settings');
      }
      
      toast({
        title: "Settings Saved",
        description: "Your business hours and settings have been updated.",
      });
    } catch (error) {
      console.error('Error saving business hours:', error);
      toast({
        title: "Error",
        description: "Failed to save business settings. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  // Effect to load saved settings from API
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const response = await fetch('/api/business-settings', {
          credentials: 'include',
        });
        const data = await response.json();
        
        if (data.success && data.settings) {
          const settings = data.settings;
          setBusinessHours({
            startHour: settings.startHour,
            startMinute: settings.startMinute,
            endHour: settings.endHour,
            endMinute: settings.endMinute,
            lunchHour: settings.lunchHour,
            lunchMinute: settings.lunchMinute,
            daysOfWeek: settings.daysOfWeek,
          });
          setEnableLunchBreak(settings.enableLunchBreak);
          setAllowWeekendBookings(settings.allowWeekendBookings);
          setHalfHourIncrements(settings.halfHourIncrements);
          setMinimumNoticeHours(settings.minimumNoticeHours);
          setMaxDriveTimeMinutes(settings.maxDriveTimeMinutes || 26);
          setEtaPadding(settings.etaPadding || 15);
          setGooglePlaceId(settings.googlePlaceId || '');
        }
      } catch (e) {
        console.error('Error loading business settings:', e);
      }
    };
    
    loadSettings();
  }, []);
  
  const formatTimeDisplay = (hour: number, minute: number) => {
    const hourDisplay = hour % 12 === 0 ? 12 : hour % 12;
    const ampm = hour < 12 ? 'AM' : 'PM';
    return `${hourDisplay}:${minute.toString().padStart(2, '0')} ${ampm}`;
  };
  
  const toggleDayOfWeek = (day: number) => {
    if (businessHours.daysOfWeek.includes(day)) {
      setBusinessHours({
        ...businessHours,
        daysOfWeek: businessHours.daysOfWeek.filter(d => d !== day)
      });
    } else {
      setBusinessHours({
        ...businessHours,
        daysOfWeek: [...businessHours.daysOfWeek, day].sort()
      });
    }
  };
  
  return (
    <div className="container mx-auto py-6 space-y-8">
      <header className="flex flex-col md:flex-row justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Business Settings</h1>
          <p className="text-gray-500">Configure your business hours and booking settings</p>
        </div>
        
        <div className="mt-4 md:mt-0 space-y-2 md:space-y-0 md:flex items-center space-x-4">
          <Button onClick={() => setLocation('/dashboard')}>
            Back to Dashboard
          </Button>
        </div>
      </header>
      
      <Tabs defaultValue="hours">
        <TabsList className="grid w-full md:w-auto grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="hours" className="flex items-center">
            <Clock className="mr-2 h-4 w-4" />
            Business Hours
          </TabsTrigger>
          <TabsTrigger value="booking" className="flex items-center">
            <Calendar className="mr-2 h-4 w-4" />
            Booking Settings
          </TabsTrigger>
          <TabsTrigger value="google" className="flex items-center">
            <LinkIcon className="mr-2 h-4 w-4" />
            Google Integration
          </TabsTrigger>
          <TabsTrigger value="branding" className="flex items-center">
            <Settings className="mr-2 h-4 w-4" />
            Branding
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center">
            <Settings className="mr-2 h-4 w-4" />
            Notifications
          </TabsTrigger>
        </TabsList>
        
        {/* Business Hours Tab */}
        <TabsContent value="hours" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center">
                  <Clock className="mr-2 h-5 w-5" />
                  Business Hours
                </div>
              </CardTitle>
              <CardDescription>
                Set your business hours and availability for appointments
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Working Days */}
              <div className="space-y-2">
                <Label>Working Days</Label>
                <div className="flex flex-wrap gap-2">
                  {daysOfWeek.map(day => (
                    <Button
                      key={day.value}
                      type="button"
                      variant={businessHours.daysOfWeek.includes(day.value) ? "default" : "outline"}
                      className="capitalize"
                      onClick={() => toggleDayOfWeek(day.value)}
                    >
                      {day.label.slice(0, 3)}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Start Time */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <Label htmlFor="startTime">Opening Time</Label>
                  <div className="flex space-x-2">
                    <Select
                      value={businessHours.startHour.toString()}
                      onValueChange={(value) => setBusinessHours({
                        ...businessHours,
                        startHour: parseInt(value)
                      })}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Hour" />
                      </SelectTrigger>
                      <SelectContent>
                        {hours.map(hour => (
                          <SelectItem key={hour} value={hour.toString()}>
                            {hour === 0 ? '12 AM' : hour === 12 ? '12 PM' : hour < 12 ? `${hour} AM` : `${hour - 12} PM`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Select
                      value={businessHours.startMinute.toString()}
                      onValueChange={(value) => setBusinessHours({
                        ...businessHours,
                        startMinute: parseInt(value)
                      })}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Minute" />
                      </SelectTrigger>
                      <SelectContent>
                        {minutes.map(minute => (
                          <SelectItem key={minute} value={minute.toString()}>
                            {minute.toString().padStart(2, '0')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {/* End Time */}
                <div className="space-y-1">
                  <Label htmlFor="endTime">Closing Time</Label>
                  <div className="flex space-x-2">
                    <Select
                      value={businessHours.endHour.toString()}
                      onValueChange={(value) => setBusinessHours({
                        ...businessHours,
                        endHour: parseInt(value)
                      })}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Hour" />
                      </SelectTrigger>
                      <SelectContent>
                        {hours.map(hour => (
                          <SelectItem key={hour} value={hour.toString()}>
                            {hour === 0 ? '12 AM' : hour === 12 ? '12 PM' : hour < 12 ? `${hour} AM` : `${hour - 12} PM`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Select
                      value={businessHours.endMinute.toString()}
                      onValueChange={(value) => setBusinessHours({
                        ...businessHours,
                        endMinute: parseInt(value)
                      })}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Minute" />
                      </SelectTrigger>
                      <SelectContent>
                        {minutes.map(minute => (
                          <SelectItem key={minute} value={minute.toString()}>
                            {minute.toString().padStart(2, '0')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              
              {/* Lunch Break Toggle */}
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="enableLunchBreak">Enable Lunch Break</Label>
                  <p className="text-sm text-gray-500">Block appointments during lunch hour</p>
                </div>
                <Switch
                  id="enableLunchBreak"
                  checked={enableLunchBreak}
                  onCheckedChange={setEnableLunchBreak}
                  data-testid="switch-enable-lunch-break"
                />
              </div>
              
              {/* Lunch Time - only shown when enabled */}
              {enableLunchBreak && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="lunchTime">Lunch Time (Not bookable)</Label>
                    <div className="flex space-x-2">
                      <Select
                        value={businessHours.lunchHour.toString()}
                        onValueChange={(value) => setBusinessHours({
                          ...businessHours,
                          lunchHour: parseInt(value)
                        })}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Hour" />
                        </SelectTrigger>
                        <SelectContent>
                          {hours.map(hour => (
                            <SelectItem key={hour} value={hour.toString()}>
                              {hour === 0 ? '12 AM' : hour === 12 ? '12 PM' : hour < 12 ? `${hour} AM` : `${hour - 12} PM`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      
                      <Select
                        value={businessHours.lunchMinute.toString()}
                        onValueChange={(value) => setBusinessHours({
                          ...businessHours,
                          lunchMinute: parseInt(value)
                        })}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Minute" />
                        </SelectTrigger>
                        <SelectContent>
                          {minutes.map(minute => (
                            <SelectItem key={minute} value={minute.toString()}>
                              {minute.toString().padStart(2, '0')}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Summary */}
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <h3 className="font-medium mb-2">Business Hours Summary</h3>
                <p>Working days: {businessHours.daysOfWeek.map(day => daysOfWeek.find(d => d.value === day)?.label.slice(0, 3)).join(', ')}</p>
                <p>Hours: {formatTimeDisplay(businessHours.startHour, businessHours.startMinute)} to {formatTimeDisplay(businessHours.endHour, businessHours.endMinute)}</p>
                {enableLunchBreak && (
                  <p>Lunch break: {formatTimeDisplay(businessHours.lunchHour, businessHours.lunchMinute)} (1 hour)</p>
                )}
                {!enableLunchBreak && (
                  <p>Lunch break: Disabled - appointments available all day</p>
                )}
              </div>
            </CardContent>
            
            <CardFooter>
              <Button 
                onClick={handleSaveBusinessHours} 
                disabled={isSaving}
                className="ml-auto"
              >
                {isSaving ? 'Saving...' : 'Save Business Hours'}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Booking Settings Tab */}
        <TabsContent value="booking" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center">
                  <Calendar className="mr-2 h-5 w-5" />
                  Appointment Settings
                </div>
              </CardTitle>
              <CardDescription>
                Configure how customers can book appointments
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="allowWeekendBookings">Allow Weekend Bookings</Label>
                  <p className="text-sm text-gray-500">For emergency services only</p>
                </div>
                <Switch
                  id="allowWeekendBookings"
                  checked={allowWeekendBookings}
                  onCheckedChange={setAllowWeekendBookings}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="halfHourIncrements">Half-hour Booking Increments</Label>
                  <p className="text-sm text-gray-500">Allow 30-minute booking slots</p>
                </div>
                <Switch
                  id="halfHourIncrements"
                  checked={halfHourIncrements}
                  onCheckedChange={setHalfHourIncrements}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="minimumNoticeHours">Minimum Notice Period (hours)</Label>
                <Input
                  id="minimumNoticeHours"
                  type="number"
                  min="0"
                  max="168"
                  value={minimumNoticeHours}
                  onChange={(e) => setMinimumNoticeHours(parseInt(e.target.value) || 0)}
                  placeholder="Enter hours (e.g., 24)"
                  data-testid="input-minimum-notice-hours"
                />
                <p className="text-sm text-gray-500">
                  Minimum hours before customers can book. Examples: 0 (no minimum), 2, 24, 48
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="maxDriveTimeMinutes">Maximum Service Area Drive Time (minutes)</Label>
                <Input
                  id="maxDriveTimeMinutes"
                  type="number"
                  min="1"
                  max="120"
                  value={maxDriveTimeMinutes}
                  onChange={(e) => setMaxDriveTimeMinutes(parseInt(e.target.value) || 26)}
                  placeholder="Enter minutes (e.g., 26)"
                  data-testid="input-max-drive-time"
                />
                <p className="text-sm text-gray-500">
                  Maximum drive time from your Tulsa base. Customers outside this area will be offered extended-area booking. Examples: 15, 26, 30, 45
                </p>
              </div>
              
              <div className="space-y-2">
                <Label>Maximum Future Booking</Label>
                <Select defaultValue="30">
                  <SelectTrigger>
                    <SelectValue placeholder="Select days" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">1 week</SelectItem>
                    <SelectItem value="14">2 weeks</SelectItem>
                    <SelectItem value="30">1 month</SelectItem>
                    <SelectItem value="90">3 months</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-gray-500">
                  How far in advance customers can book appointments
                </p>
              </div>
            </CardContent>
            
            <CardFooter>
              <Button 
                onClick={handleSaveBusinessHours} 
                disabled={isSaving}
                className="ml-auto"
              >
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? 'Saving...' : 'Save Settings'}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Google Integration Tab */}
        <TabsContent value="google" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center">
                  <LinkIcon className="mr-2 h-5 w-5" />
                  Google Business Integration
                </div>
              </CardTitle>
              <CardDescription>
                Connect your Google Business Profile to sync photos and reviews
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="googlePlaceId">Google Place ID</Label>
                <Input
                  id="googlePlaceId"
                  value={googlePlaceId}
                  onChange={(e) => setGooglePlaceId(e.target.value)}
                  placeholder="ChIJ..."
                  data-testid="input-google-place-id"
                />
                <p className="text-sm text-gray-500">
                  Your Google Business Profile Place ID (e.g., "ChIJVX4B3d2TtocRCjnc7bJevHw")
                </p>
              </div>
              
              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">How to find your Google Place ID:</h4>
                <ol className="text-sm text-blue-800 dark:text-blue-200 space-y-1 list-decimal list-inside">
                  <li>Go to <a href="https://www.google.com/maps" target="_blank" rel="noopener noreferrer" className="underline">Google Maps</a></li>
                  <li>Search for "Clean Machine Tulsa" (or your business name)</li>
                  <li>Look at the URL - it will contain your Place ID after "!1s"</li>
                  <li>Or use Google's <a href="https://developers.google.com/maps/documentation/places/web-service/place-id" target="_blank" rel="noopener noreferrer" className="underline">Place ID Finder</a></li>
                </ol>
              </div>
              
              <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  <strong>Note:</strong> This Place ID is used to automatically sync your Google Business Profile photos and reviews. Make sure you enter the correct ID for your business.
                </p>
              </div>
            </CardContent>
            
            <CardFooter>
              <Button 
                onClick={handleSaveBusinessHours} 
                disabled={isSaving}
                className="ml-auto"
                data-testid="button-save-google-place-id"
              >
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? 'Saving...' : 'Save Settings'}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Branding Tab */}
        <TabsContent value="branding" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center">
                  <ImageIcon className="mr-2 h-5 w-5" />
                  Logo Options
                </div>
              </CardTitle>
              <CardDescription>
                AI-generated logo options for your business
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Blue Logo */}
                <div className="space-y-3">
                  <div className="aspect-square bg-white rounded-lg border-2 border-gray-200 p-6 flex items-center justify-center">
                    <img 
                      src={logoBlue} 
                      alt="Clean Machine Blue Logo" 
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-lg">Blue Logo</h3>
                    <p className="text-sm text-gray-500">Minimalist professional design</p>
                  </div>
                </div>

                {/* Circular Badge */}
                <div className="space-y-3">
                  <div className="aspect-square bg-white rounded-lg border-2 border-gray-200 p-6 flex items-center justify-center">
                    <img 
                      src={logoBadge} 
                      alt="Clean Machine Circular Badge" 
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-lg">Circular Badge</h3>
                    <p className="text-sm text-gray-500">Modern badge design (current PWA icon)</p>
                  </div>
                </div>

                {/* Hexagonal Shield */}
                <div className="space-y-3">
                  <div className="aspect-square bg-white rounded-lg border-2 border-gray-200 p-6 flex items-center justify-center">
                    <img 
                      src={logoShield} 
                      alt="Clean Machine Hexagonal Shield" 
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-lg">Hexagonal Shield</h3>
                    <p className="text-sm text-gray-500">Professional emblem style</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <p className="text-sm text-blue-800 dark:text-blue-200">
                  <strong>Note:</strong> These logos are AI-generated and ready to use. The circular badge is currently being used as your PWA app icon. You can download any of these images for use in marketing materials, social media, or other branding needs.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center">
                  <Settings className="mr-2 h-5 w-5" />
                  Notification Settings
                </div>
              </CardTitle>
              <CardDescription>
                Configure notification preferences for appointments
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="etaPadding">ETA Buffer Time (minutes)</Label>
                <Input
                  id="etaPadding"
                  type="number"
                  min="0"
                  max="60"
                  value={etaPadding}
                  onChange={(e) => setEtaPadding(parseInt(e.target.value) || 15)}
                  data-testid="input-eta-padding"
                />
                <p className="text-sm text-gray-500">
                  Extra minutes to add to travel time estimates (recommended: 10-20 minutes for traffic/parking)
                </p>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="emailNotifications">Email Notifications</Label>
                  <p className="text-sm text-gray-500">Receive appointment notifications via email</p>
                </div>
                <Switch
                  id="emailNotifications"
                  defaultChecked={true}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="smsNotifications">SMS Notifications</Label>
                  <p className="text-sm text-gray-500">Receive appointment notifications via SMS</p>
                </div>
                <Switch
                  id="smsNotifications"
                  defaultChecked={true}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Reminder Timing</Label>
                <Select defaultValue="24">
                  <SelectTrigger>
                    <SelectValue placeholder="Select hours" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 hour before</SelectItem>
                    <SelectItem value="2">2 hours before</SelectItem>
                    <SelectItem value="24">24 hours before</SelectItem>
                    <SelectItem value="48">48 hours before</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-gray-500">
                  When to send appointment reminders
                </p>
              </div>
            </CardContent>
            
            <CardFooter>
              <Button 
                onClick={handleSaveBusinessHours} 
                disabled={isSaving}
                className="ml-auto"
              >
                <Save className="mr-2 h-4 w-4" />
                {isSaving ? 'Saving...' : 'Save Settings'}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}